cd ./attachments
rm photo*.png